from docopt import docopt

def main():
    arguments = docopt(__doc__)
    print(arguments)

if __name__ == "__main__":
    main()
